//
//  BottomDropAnimationView.swift
//  AppearAnimations
//
//  Created by Sajid on 26/06/25.
//


import SwiftUI

struct BottomDropAnimationView: View {
    var body: some View {
        VStack(spacing: 30) {
            Spacer()
            Image(systemName: "drop.fill")
                .resizable()
                .frame(width: 80, height: 100)
                .foregroundColor(.blue)
                .appearAnimated(.bottomDrop(bounceHeight: 80),delay: 0.1,duration: 1)
            Spacer()
        }
        .navigationTitle("Drop In")
    }
}

struct BottomDropAnimationView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            BottomDropAnimationView()
        }
    }
}
import SwiftUI

struct BottomFadeRiseAnimationView: View {
    var body: some View {
        VStack {
            Spacer()
            Text("Fade + Rise")
                .font(.title)
                .padding()
                .background(Color.indigo)
                .foregroundColor(.white)
                .cornerRadius(10)
                .appearAnimated(.bottomFadeRise,delay: 0.1 ,duration: 1)
            Spacer()
        }
        .navigationTitle("Fade Rise")
    }
}

struct BottomFadeRiseAnimationView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            BottomFadeRiseAnimationView()
        }
    }
}
import SwiftUI

struct CombinedSlideScaleAnimationView: View {
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "paperplane.circle.fill")
                .resizable()
                .frame(width: 120, height: 120)
                .foregroundColor(.blue)
                .appearAnimated(.combined(from: .trailing, scale: 0.6),delay: 0.2,duration: 1)
                .appearAnimated(.center(scale: 0.5, fade: true),delay: 0.3,duration: 1)

            Text("Combined Slide + Scale")
                .font(.headline)
                .appearAnimated(.combined(from: .trailing, scale: 0.7), delay: 0.3, duration: 1)
        }
        .navigationTitle("Combined Animation")
    }
}

struct CombinedSlideScaleAnimationView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            CombinedSlideScaleAnimationView()
        }
    }
}
import SwiftUI

struct SlideFromEdgeAnimationView: View {
    var body: some View {
        VStack {
            Spacer()
            Text("Slide Leading")
                .font(.largeTitle)
                .padding()
                .background(Color.blue.opacity(0.7))
                .cornerRadius(10)
                .foregroundColor(.white)
                .appearAnimated(.slide(from: .leading),delay: 0.2, duration: 1)
            Text("Slide Trailing")
                .font(.largeTitle)
                .padding()
                .background(Color.blue.opacity(0.7))
                .cornerRadius(10)
                .foregroundColor(.white)
                .appearAnimated(.slide(from: .trailing),delay: 0.4, duration: 1)
            Spacer()
        }
        .navigationTitle("Slide From Leading and Trailing")
    }
}

struct SlideFromEdgeAnimationView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            SlideFromEdgeAnimationView()
        }
    }
}
import SwiftUI

struct CenterAnimationView: View {
    var body: some View {
        VStack(spacing: 30) {
            Image(systemName: "star.circle.fill")
                .resizable()
                .frame(width: 100, height: 100)
                .foregroundColor(.yellow)
                .appearAnimated(.center(scale: 0, fade: true),delay: 0.1,duration: 1)
            
            Text("Centered Scaling")
                .font(.headline)
                .appearAnimated(.fromBottom , delay: 0.3, duration: 0.8)
        }
        .navigationTitle("Center Scale")
    }
}

struct CenterAnimationView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            CenterAnimationView()
        }
    }
}
import SwiftUI

struct BottomBounceAnimationView: View {
    var body: some View {
        VStack {
            Spacer()
            Button("Bounce Button") {}
                .font(.title2)
                .padding()
                .background(Color.purple)
                .foregroundColor(.white)
                .cornerRadius(12)
                .appearAnimated(.bottomBounce,delay: 0.3,duration: 1)
            Spacer()
        }
        .navigationTitle("Bottom Bounce")
    }
}

struct BottomBounceAnimationView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            BottomBounceAnimationView()
        }
    }
}
import SwiftUI

struct FromBottomAnimationView: View {
    var body: some View {
        VStack(spacing: 40) {
            Spacer()
            RoundedRectangle(cornerRadius: 25)
                .fill(Color.orange)
                .frame(width: 150, height: 150)
                .appearAnimated(.fromBottom , delay: 0.2,duration: 1)
            Text("Slide from Bottom")
                .font(.largeTitle)
                .bold()
                .appearAnimated(.fromBottom , delay: 0.3 )
            Spacer()
        }
        .padding()
        .navigationTitle("From Bottom")
    }
}

struct FromBottomAnimationView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            FromBottomAnimationView()
        }
    }
}
import SwiftUI

struct FromTopAnimationView: View {
    var body: some View {
        VStack(spacing: 30) {
            Text("Slide from Top")
                .font(.largeTitle)
                .bold()
                .appearAnimated(.fromTop , delay: 0.1 )

            Circle()
                .fill(Color.green)
                .frame(width: 100, height: 100)
                .appearAnimated(.fromTop, delay: 0.3,duration: 1)
        }
        .padding()
        .navigationTitle("From Top")
    }
}

struct FromTopAnimationView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            FromTopAnimationView() 
        }
    }
}
import SwiftUI

struct FadeAnimationView: View {
    var body: some View {
        VStack(spacing: 20) {
            Text("Fade In")
                .font(.title)
                .bold()
                .appearAnimated(.fade)
            
            Image(systemName: "heart.fill")
                .resizable()
                .scaledToFit()
                .frame(width: 120)
                .foregroundColor(.red)
                .appearAnimated(.fade, delay: 0.3,duration: 1)
        }
        .padding()
        .navigationTitle("Fade")
    }
}

struct FadeAnimationView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            FadeAnimationView()
        }
    }
}
import SwiftUI

struct CombinedAnimationsView: View {
    var body: some View {
        ScrollView {
            VStack(spacing: 40) {
                
                // Title
                Text("⚡️ All Animations Showcase")
                    .font(.largeTitle)
                    .bold()
                    .multilineTextAlignment(.center)
                    .padding()
                    .appearAnimated(.center(scale: 0.5), delay: 0.0, duration: 1)
                
                // Row 1 - Fade, Scale
                HStack(spacing: 30) {
                    Circle()
                        .fill(Color.red)
                        .frame(width: 80, height: 80)
                        .overlay(Text("Fade").foregroundColor(.white))
                        .appearAnimated(.fade, delay: 0.1, duration: 1)

                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.green)
                        .frame(width: 80, height: 80)
                        .overlay(Text("Scale").foregroundColor(.white))
                        .appearAnimated(.scale(from: 0.3), delay: 0.2, duration: 1)
                }

                // Row 2 - From Top / Bottom
                HStack(spacing: 30) {
                    Image(systemName: "arrow.down")
                        .resizable()
                        .frame(width: 50, height: 50)
                        .foregroundColor(.blue)
                        .appearAnimated(.fromTop, delay: 0.3, duration: 1)

                    Image(systemName: "arrow.up")
                        .resizable()
                        .frame(width: 50, height: 50)
                        .foregroundColor(.purple)
                        .appearAnimated(.fromBottom, delay: 0.4, duration: 1)
                }

                // Row 3 - From Left / Right
                HStack(spacing: 30) {
                    Text("← Left")
                        .font(.headline)
                        .padding()
                        .background(Color.orange)
                        .cornerRadius(8)
                        .appearAnimated(.fromLeft, delay: 0.5, duration: 1)

                    Text("Right →")
                        .font(.headline)
                        .padding()
                        .background(Color.pink)
                        .cornerRadius(8)
                        .appearAnimated(.fromRight, delay: 0.6, duration: 1)
                }

                // Row 4 - Slide + Combined
                HStack(spacing: 30) {
                    Image(systemName: "bolt.circle.fill")
                        .resizable()
                        .frame(width: 60, height: 60)
                        .foregroundColor(.yellow)
                        .appearAnimated(.slide(from: .leading), delay: 0.7, duration: 1)

                    Image(systemName: "globe")
                        .resizable()
                        .frame(width: 60, height: 60)
                        .foregroundColor(.teal)
                        .appearAnimated(.combined(from: .trailing, scale: 0.7), delay: 0.8, duration: 1)
                }

                // Row 5 - Bottom Bounce, Pop
                HStack(spacing: 30) {
                    Text("Bounce")
                        .padding()
                        .background(Color.indigo)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .appearAnimated(.bottomBounce, delay: 0.9, duration: 1)

                    Text("Pop")
                        .padding()
                        .background(Color.mint)
                        .foregroundColor(.black)
                        .cornerRadius(10)
                        .appearAnimated(.bottomPop(scale: 0.7), delay: 1.0, duration: 1)
                }

                // Row 6 - FadeRise & Drop
                HStack(spacing: 30) {
                    Text("Fade ↑")
                        .font(.subheadline)
                        .padding()
                        .background(Color.gray.opacity(0.5))
                        .cornerRadius(8)
                        .appearAnimated(.bottomFadeRise, delay: 1.1, duration: 1)

                    Text("Drop ↓")
                        .font(.subheadline)
                        .padding()
                        .background(Color.black)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                        .appearAnimated(.bottomDrop(bounceHeight: 60), delay: 1.2, duration: 1)
                }
            }
            .padding(.vertical)
        }
        .navigationTitle("All Animations")
    }
}

struct CombinedAnimationsView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            CombinedAnimationsView()
        }
    }
}
