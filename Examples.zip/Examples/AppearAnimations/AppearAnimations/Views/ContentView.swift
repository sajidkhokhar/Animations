//
//  ContentView.swift
//  AppearAnimations
//
//  Created by Sajid on 26/06/25.
//

import SwiftUI

import SwiftUI

struct AppearAnimationView: View {
    var body: some View {
        NavigationView {
            List {
                NavigationLink("Fade", destination: FadeAnimationView())
                NavigationLink("From Top", destination: FromTopAnimationView())
                NavigationLink("From Bottom", destination: FromBottomAnimationView())
                NavigationLink("Bottom Bounce", destination: BottomBounceAnimationView())
                NavigationLink("Center + Bottom Animation", destination: CenterAnimationView())
                NavigationLink("Slide from Leading and Trailing", destination: SlideFromEdgeAnimationView())
                NavigationLink("Combined Slide + Scale", destination: CombinedSlideScaleAnimationView())
                NavigationLink("Fade + Rise", destination: BottomFadeRiseAnimationView())
                NavigationLink("Bottom Drop", destination: BottomDropAnimationView())
                NavigationLink("🔥 All Combined Animations", destination: CombinedAnimationsView())

            }
            .navigationTitle("Animation Examples")
        }
    }
}

struct DemoListView_Previews: PreviewProvider {
    static var previews: some View {
        AppearAnimationView()
    }
}


#Preview {
    AppearAnimationView()
}
