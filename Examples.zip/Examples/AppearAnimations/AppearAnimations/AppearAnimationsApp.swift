//
//  AppearAnimationsApp.swift
//  AppearAnimations
//
//  Created by Sajid on 26/06/25.
//

import SwiftUI

@main
struct AppearAnimationsApp: App {
    var body: some Scene {
        WindowGroup {
            AppearAnimationView()
        }
    }
}
